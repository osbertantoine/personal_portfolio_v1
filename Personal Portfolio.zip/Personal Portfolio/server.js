const express = require('./config/express.js');

express().listen(3000, () => {});