const express = require('express');

const router = express.Router();

router.get('/', (req, res, next) => {
    res.render('index', {
        title: "index"
    })
})

router.get('/about', (req, res, next) => {
    res.render('partials/about', {
        title: "About"
    })
})

router.get('/projects', (req, res, next) => {
    res.render('partials/projects', {
        title: "Projects"
    })
})

router.get('/services', (req, res, next) => {
    res.render('partials/services', {
        title: "services"
    })
})

router.get('/contact', (req, res, next) => {
    res.render('partials/contact', {
        title: "Contact"
    })
})

module.exports = router;