## commands for version control
1. commit stage
- git add . (tracking all the files)
- git add file_path (tracking the specific file)
- git commit -m "msg" (commit your current stage which is all the files tracking right now)
2. remote sync stage
- git push origin branch_name


## commands to create a new file in MS
- New-Item -ItemType File "file_path"
e.g. create a readme file under the current folder
```
New-Item -ItemType File "./README.md"
```